function HorárioTrabalho(salário) {
    return(salário / 160)
}

console.log(HorárioTrabalho(555))