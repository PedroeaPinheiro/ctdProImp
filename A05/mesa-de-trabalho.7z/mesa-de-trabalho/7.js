function caps(string) {
    return string.toUpperCase()
}

console.log(caps('olá'));