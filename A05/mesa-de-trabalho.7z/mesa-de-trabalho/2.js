function StringxUrl(nome) {
    return(`http://www.${nome}.com.br`)

}

console.log(StringxUrl(""))