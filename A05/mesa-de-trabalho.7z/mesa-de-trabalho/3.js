function exclamação(frase) {
    return(`${frase}!`)
}

console.log(exclamação(""))