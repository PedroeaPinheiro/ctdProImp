function PolexCenti(polegadas) {
    return(polegadas * 2.54)
}

console.log(PolexCenti(11));
