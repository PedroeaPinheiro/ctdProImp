function IMC(altura,peso) {
    return(peso / (altura * altura))
}

console.log(IMC())