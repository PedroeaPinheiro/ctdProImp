function IdadeCach(idade) {
    return(idade * 7)
}

console.log(IdadeCach(5))